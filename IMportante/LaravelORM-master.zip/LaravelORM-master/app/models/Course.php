<?php

class Course extends Eloquent {

}

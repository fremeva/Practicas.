<?php

class UserTableSeeder extends Seeder {

    public function run() {
        DB::table('users')->delete();

        User::create(array(
            'id' => 1,
            'name' => 'Jairo Serrano',
            'email' => 'jairo.serrano@gmail.com',
            'username' => 'JairoSerrano',
            'password' => Hash::make('12345'),
        ));

        User::create(array(
            'id' => 2,
            'name' => 'Gloria Bautista',
            'email' => 'bautistalasprilla.gloriaisabel@gmail.com',
            'username' => 'GloriaBautista',
            'password' => Hash::make('12345'),
        ));

        User::create(array(
            'id' => 3,
            'name' => 'Luz Roblez',
            'email' => 'lrobles@unitecnologica.edu.co',
            'username' => 'LuzRoblez',
            'password' => Hash::make('12345'),
        ));

        User::create(array(
            'id' => 4,
            'name' => 'Isaac Zuñiga',
            'email' => 'izuniga@unitecnologica.edu.co',
            'username' => 'IsaacZuniga',
            'password' => Hash::make('12345'),
        ));

        User::create(array(
            'id' => 5,
            'name' => 'Estudiante Uno',
            'email' => 'euno@unitecnologica.edu.co',
            'username' => 'EstudianteUno',
            'password' => Hash::make('12345'),
        ));

        User::create(array(
            'id' => 6,
            'name' => 'Estudiante Dos',
            'email' => 'edos@unitecnologica.edu.co',
            'username' => 'EstudianteDos',
            'password' => Hash::make('12345'),
        ));

        User::create(array(
            'id' => 7,
            'name' => 'Estudiante Tres',
            'email' => 'etres@unitecnologica.edu.co',
            'username' => 'EstudianteTres',
            'password' => Hash::make('12345'),
        ));


    }

}

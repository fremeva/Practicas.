<?php

class GradesTableSeeder extends Seeder {

    public function run() {
        DB::table('grades')->delete();

        Grade::create(array(
            'id' => 1,
            'grade' => 3.1,
            'user_id' => 1,
            'course_id' => 1,
        ));
        Grade::create(array(
            'id' => 2,
            'grade' => 3.2,
            'user_id' => 1,
            'course_id' => 1,
        ));

        Grade::create(array(
            'id' => 3,
            'grade' => 3.3,
            'user_id' => 2,
            'course_id' => 1,
        ));

        Grade::create(array(
            'id' => 4,
            'grade' => 3.4,
            'user_id' => 3,
            'course_id' => 1,
        ));

        Grade::create(array(
            'id' => 5,
            'grade' => 3.5,
            'user_id' => 4,
            'course_id' => 1,
        ));
    }

}

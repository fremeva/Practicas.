<?php

class CourseTableSeeder extends Seeder {

    public function run() {
        DB::table('courses')->delete();

        Course::create(array(
            'id' => 1,
            'name' => 'Seminario de Ingeniería de Sistemas',
        ));

        Course::create(array(
            'id' => 2,
            'name' => 'Diseño de Ambientes Web 3',
        ));

    }

}
